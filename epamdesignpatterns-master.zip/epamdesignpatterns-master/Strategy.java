package com.epam.design_pats;
public interface Strategy {
   public int doOperation(int num1, int num2);
}